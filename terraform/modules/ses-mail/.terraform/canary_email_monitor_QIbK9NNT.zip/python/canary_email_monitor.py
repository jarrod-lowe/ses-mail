"""
Email Canary Monitor - CloudWatch Synthetics Canary

This canary sends hourly test emails through the SES inbound pipeline and monitors
end-to-end delivery latency. It validates MTA-STS configuration, sends via SMTP,
and polls DynamoDB for completion confirmation.

Runtime: syn-python-selenium-4.1 (Python 3.11)
"""

import smtplib
import time
import json
import re
import os
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

import boto3
from botocore.exceptions import ClientError

# AWS clients
ssm = boto3.client('ssm')
dynamodb = boto3.client('dynamodb')

# Environment variables (set by CloudWatch Synthetics)
ENVIRONMENT = os.environ.get('ENVIRONMENT', 'test')
DOMAIN = os.environ.get('DOMAIN')
CANARY_TIMEOUT = 300  # 5 minutes in seconds
POLL_INTERVAL = 10  # Poll every 10 seconds
DYNAMODB_TABLE_NAME = f"ses-mail-email-routing-{ENVIRONMENT}"

# Cache for integration test token
_integration_test_token = None


def handler(event, context):
    """
    CloudWatch Synthetics canary handler.

    This function is invoked by CloudWatch Synthetics on schedule.
    It performs end-to-end email testing and returns success/failure.

    Args:
        event: Synthetics event (contains timestamp)
        context: Lambda context

    Returns:
        str: Success message if email delivered within timeout

    Raises:
        Exception: If canary fails (timeout, MTA-STS error, SMTP error, etc.)
    """
    start_time = time.time()

    if not DOMAIN:
        raise ValueError("DOMAIN environment variable must be set")

    print(f"Starting canary test for domain: {DOMAIN}")

    # Step 1: Validate MTA-STS configuration (client-side check)
    print("Step 1: Validating MTA-STS configuration...")
    validate_mta_sts(DOMAIN)
    print("✓ MTA-STS configuration valid")

    # Step 2: Resolve MX records
    print("Step 2: Resolving MX records...")
    mx_host = resolve_mx_records(DOMAIN)
    print(f"✓ Resolved MX: {mx_host}")

    # Step 3: Load integration test token from SSM
    print("Step 3: Loading integration test token from SSM...")
    integration_token = get_integration_test_token()
    print("✓ Integration test token loaded")

    # Step 4: Send email via SMTP with STARTTLS
    print("Step 4: Sending test email via SMTP...")
    message_id = send_test_email(mx_host, DOMAIN, integration_token)
    print(f"✓ Email sent successfully, SES Message ID: {message_id}")

    # Step 5: Poll DynamoDB for completion record
    print("Step 5: Polling DynamoDB for completion confirmation...")
    completion_time = poll_dynamodb_for_completion(message_id, start_time)

    # Calculate total latency
    total_latency = completion_time - start_time
    print(f"✓ Email delivered successfully in {total_latency:.2f} seconds")

    return f"Canary test passed - Email delivered in {total_latency:.2f}s (Message ID: {message_id})"


def validate_mta_sts(domain):
    """
    Validate MTA-STS configuration for the domain (client-side check).

    Simulates a real email client checking MTA-STS policy before sending.
    Fails if MTA-STS is misconfigured or unavailable.

    Args:
        domain: Domain to validate (e.g., "example.com")

    Raises:
        Exception: If MTA-STS is misconfigured or unavailable
    """
    import dns.resolver

    # Step 1: Check DNS TXT record for MTA-STS
    mta_sts_record = f"_mta-sts.{domain}"
    try:
        answers = dns.resolver.resolve(mta_sts_record, 'TXT')
        record_found = False
        for rdata in answers:
            txt_value = rdata.to_text().strip('"')
            if txt_value.startswith('v=STSv1'):
                record_found = True
                print(f"  Found MTA-STS DNS record: {txt_value}")
                break

        if not record_found:
            raise Exception(f"MTA-STS DNS record exists but doesn't contain v=STSv1: {mta_sts_record}")

    except dns.resolver.NXDOMAIN:
        raise Exception(f"MTA-STS DNS record not found: {mta_sts_record}")
    except Exception as e:
        raise Exception(f"Failed to resolve MTA-STS DNS record: {e}")

    # Step 2: Fetch MTA-STS policy file
    policy_url = f"https://mta-sts.{domain}/.well-known/mta-sts.txt"
    try:
        with urlopen(policy_url, timeout=10) as response:
            policy_content = response.read().decode('utf-8')
            print(f"  Fetched MTA-STS policy from: {policy_url}")

            # Validate policy has mode=enforce
            if 'mode: enforce' not in policy_content:
                raise Exception(f"MTA-STS policy does not have mode=enforce: {policy_content[:200]}")

            # Validate policy has version
            if 'version: STSv1' not in policy_content:
                raise Exception(f"MTA-STS policy missing version: STSv1")

            print(f"  MTA-STS policy validated (mode=enforce)")

    except (URLError, HTTPError) as e:
        raise Exception(f"Failed to fetch MTA-STS policy from {policy_url}: {e}")


def resolve_mx_records(domain):
    """
    Resolve MX records for the domain.

    Args:
        domain: Domain to resolve (e.g., "example.com")

    Returns:
        str: MX hostname with highest priority (lowest number)

    Raises:
        Exception: If no MX records found
    """
    import dns.resolver

    try:
        answers = dns.resolver.resolve(domain, 'MX')
        # Sort by priority (lowest number = highest priority)
        mx_records = sorted([(rdata.preference, str(rdata.exchange).rstrip('.'))
                            for rdata in answers])

        if not mx_records:
            raise Exception(f"No MX records found for domain: {domain}")

        # Return MX with highest priority
        mx_host = mx_records[0][1]
        print(f"  Found {len(mx_records)} MX records, using: {mx_host} (priority {mx_records[0][0]})")
        return mx_host

    except dns.resolver.NXDOMAIN:
        raise Exception(f"Domain not found: {domain}")
    except Exception as e:
        raise Exception(f"Failed to resolve MX records for {domain}: {e}")


def get_integration_test_token():
    """
    Load integration test token from SSM Parameter Store.

    Returns:
        str: Integration test token value

    Raises:
        Exception: If token cannot be loaded
    """
    global _integration_test_token

    if _integration_test_token is not None:
        return _integration_test_token

    try:
        parameter_name = f'/ses-mail/{ENVIRONMENT}/integration-test-token'
        response = ssm.get_parameter(Name=parameter_name, WithDecryption=True)
        _integration_test_token = response['Parameter']['Value']
        return _integration_test_token
    except Exception as e:
        raise Exception(f"Failed to load integration test token from SSM: {e}")


def send_test_email(mx_host, domain, integration_token):
    """
    Send test email via SMTP with STARTTLS on port 2587.

    Args:
        mx_host: MX hostname to connect to
        domain: Domain for From/To addresses
        integration_token: Integration test token (X-Integration-Test-Token header)

    Returns:
        str: SES message ID extracted from SMTP response

    Raises:
        Exception: If SMTP send fails or message ID cannot be extracted
    """
    timestamp = datetime.utcnow().isoformat() + 'Z'
    from_addr = f"canary-sender@{domain}"
    to_addr = f"canary@{domain}"
    subject = f"Canary Test - {timestamp}"

    # Create email message
    msg = MIMEMultipart()
    msg['From'] = from_addr
    msg['To'] = to_addr
    msg['Subject'] = subject
    msg['X-Integration-Test-Token'] = integration_token

    # Email body
    body = f"""This is an automated canary test email sent at {timestamp}.

This email validates the end-to-end email delivery pipeline:
- MTA-STS validation
- SMTP delivery via port 2587 with STARTTLS
- SES inbound processing
- Router enrichment
- EventBridge routing
- Canary monitor Lambda processing
- DynamoDB completion record

If you receive this email, please disregard it.
"""
    msg.attach(MIMEText(body, 'plain'))

    # Connect to SMTP server with STARTTLS
    try:
        smtp = smtplib.SMTP(mx_host, 2587, timeout=30)
        smtp.set_debuglevel(0)  # Set to 1 for debugging

        # Upgrade to TLS
        smtp.starttls()

        # Send email
        smtp.sendmail(from_addr, to_addr, msg.as_string())

        # Get SMTP response to extract message ID
        # SES responds with: 250 Ok <message-id>
        code, response_msg = smtp.getreply()
        smtp.quit()

        if code != 250:
            raise Exception(f"SMTP send failed with code {code}: {response_msg}")

        # Extract message ID from response (format: "250 Ok <message-id>")
        message_id = extract_message_id_from_response(response_msg)

        if not message_id:
            raise Exception(f"Failed to extract message ID from SMTP response: {response_msg}")

        return message_id

    except Exception as e:
        raise Exception(f"SMTP send failed: {e}")


def extract_message_id_from_response(response):
    """
    Extract SES message ID from SMTP response.

    SES responds with format: b'Ok <message-id>' or '250 Ok <message-id>'

    Args:
        response: SMTP response (bytes or str)

    Returns:
        str: Message ID (without angle brackets) or None if not found
    """
    # Convert bytes to string if needed
    if isinstance(response, bytes):
        response = response.decode('utf-8')

    # Extract message ID using regex (matches <...>)
    match = re.search(r'<([^>]+)>', response)
    if match:
        return match.group(1)

    return None


def poll_dynamodb_for_completion(message_id, start_time):
    """
    Poll DynamoDB for canary completion record.

    Polls every 10 seconds for up to 5 minutes (CANARY_TIMEOUT).

    Args:
        message_id: SES message ID to poll for
        start_time: Time when canary started (for timeout calculation)

    Returns:
        float: Time when completion record was found (time.time())

    Raises:
        Exception: If timeout occurs before completion record found
    """
    pk = f"CANARY#{message_id}"
    sk = "COMPLETION#v1"

    max_polls = CANARY_TIMEOUT // POLL_INTERVAL

    for poll_count in range(max_polls):
        elapsed = time.time() - start_time

        try:
            response = dynamodb.get_item(
                TableName=DYNAMODB_TABLE_NAME,
                Key={
                    'PK': {'S': pk},
                    'SK': {'S': sk}
                },
                ConsistentRead=True  # Use consistent read for immediate visibility
            )

            if 'Item' in response:
                # Completion record found!
                timestamp_ms = int(response['Item']['timestamp']['N'])
                completion_time = time.time()
                print(f"  ✓ Completion record found after {elapsed:.2f}s (poll #{poll_count + 1})")
                return completion_time

            # Record not found yet, wait and retry
            if poll_count < max_polls - 1:
                print(f"  Waiting for completion... ({elapsed:.0f}s elapsed, poll #{poll_count + 1})")
                time.sleep(POLL_INTERVAL)

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code')
            if error_code == 'ResourceNotFoundException':
                raise Exception(f"DynamoDB table not found: {DYNAMODB_TABLE_NAME}")
            else:
                print(f"  Warning: DynamoDB poll failed: {e}")
                # Continue polling
                if poll_count < max_polls - 1:
                    time.sleep(POLL_INTERVAL)

    # Timeout reached
    elapsed = time.time() - start_time
    raise Exception(f"Timeout after {elapsed:.2f}s - No completion record found for message: {message_id}")
